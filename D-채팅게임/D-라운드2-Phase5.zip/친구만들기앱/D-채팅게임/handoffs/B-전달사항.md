# B에게 — 채팅 화면 관련 (D 트랙, 2026-08-19)

## D가 완성해서 넘기는 것

`app/chat/[id]/page.tsx`(대화방 서버 컴포넌트)가 완성됐다. **여기에 신고 진입점을 붙이면 된다.**

현재 헤더 구조:

```tsx
<header className="flex shrink-0 items-center gap-3 border-b border-slate-200 px-4 py-3">
  <Link href="/chat" ...>←</Link>
  <p className="flex-1 truncate font-semibold text-slate-900">{partner?.nickname}</p>
  <Link href={`/chat/${id}/meet`} ...>만났어요</Link>
</header>
```

신고 버튼은 이 헤더 안, "만났어요" 옆이나 별도 "···" 메뉴로 넣는 걸 제안한다 (최종 배치는 B 판단).
`partner?.id`로 상대방 profile id를 이미 가지고 있으니 `ReportDialog`에 그대로 넘기면 된다.

`components/MessageBubble.tsx`(D 작성)도 참고용으로 열어봐도 된다 — 색상은 `app/globals.css`의 `--brand-*` 토큰을 그대로 썼다.

## D가 B로부터 기다리는 것

`components/Avatar.tsx`가 아직 없어서, 임시로 `app/chat/page.tsx` 안에 `PlaceholderAvatar`라는 **지역 함수**(파일로 안 만듦, 이름 안 겹침)를 써서 대화방 목록의 아바타를 표시하고 있다.

Avatar.tsx가 나오면 아래 한 곳만 바꾸면 된다:

```tsx
// app/chat/page.tsx 안
// Before
<PlaceholderAvatar photoUrl={partner?.photo_url ?? null} nickname={partner?.nickname ?? '?'} />

// After
<Avatar photoUrl={partner?.photo_url ?? null} nickname={partner?.nickname ?? '?'} />
```

`PlaceholderAvatar` 함수 정의도 그때 지우면 된다. props 이름이 다르면 알려주면 D가 맞춰서 교체한다.

## 참고

- `app/chat/[id]/page.tsx` 헤더에는 현재 아바타가 없다(닉네임만). 필요하면 여기도 같이 넣어줄 수 있다.
- 진행 상황 전체 기록: `docs/agent/D-작업기록.md`

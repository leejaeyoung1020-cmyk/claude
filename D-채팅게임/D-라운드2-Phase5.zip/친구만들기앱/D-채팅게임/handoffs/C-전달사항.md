# C에게 — 신청 수락 → 채팅 연결 (D 트랙, 2026-08-19)

## D가 C로부터 기다리는 것

D는 지금 `supabase/seed.sql`의 시드 대화방 1개로 채팅 화면을 개발·검증했다. **C의 Phase 4(신청 수락 처리)가 끝나면, 실제 "수락 → 대화방 생성 → 채팅 진입" 흐름으로 한 번 더 확인이 필요하다.** (D-채팅게임/tasks.md에 이미 있는 항목이라 새 작업은 아니고, C 완료 알림만 받으면 된다.)

## C에게 참고로 알려줄 것 — 수락 처리와 D 화면 연결 방법

`respond_friend_request` RPC(수락 시)는 **대화방 id를 반환**한다 (`003_functions.sql` 참고):

```sql
create or replace function respond_friend_request(p_request uuid, p_accept boolean)
returns uuid  -- 수락이면 대화방 id, 거절이면 null
```

C의 수락 처리 서버 액션에서 이 반환값을 받아 그대로 D의 라우트로 이동시키면 자연스럽게 연결된다:

```ts
// C의 app/actions/requests.ts (예시)
const { data: conversationId } = await supabase.rpc('respond_friend_request', {
  p_request: requestId,
  p_accept: true,
})

if (conversationId) {
  redirect(`/chat/${conversationId}`)  // D의 화면으로 바로 진입
}
```

D 쪽 `/chat/[id]` 화면은 참여자 확인(`user_a`/`user_b`)만 통과하면 별도 설정 없이 바로 열린다. C에서 추가로 신경 쓸 것은 없다.

## 참고

- `app/requests` 쪽 화면 디자인과 D의 `app/chat` 색상 토큰(`--brand-*`)을 맞추면 통합 때 자연스럽다.
- 진행 상황 전체 기록: `docs/agent/D-작업기록.md`

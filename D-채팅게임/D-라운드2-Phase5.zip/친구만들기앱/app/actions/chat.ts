'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'

export type SendMessageState = { error: string | null }

const MAX_BODY_LENGTH = 1000

function isValidMessageBody(body: string): boolean {
  const value = body.trim()
  return value.length >= 1 && value.length <= MAX_BODY_LENGTH
}

/**
 * 메시지를 보낸다.
 *
 * 업무 규칙 위치 안내: 하루 신청 상한 등과 달리 메시지 전송은 RPC가 아니라
 * RLS 정책(msg_insert, 002_rls.sql)이 "내 대화방에만 보낼 수 있다"를 직접
 * 강제한다. 여기서는 형식만 검증하고, 접근 통제는 DB에 맡긴다.
 *
 * conversationId는 서버 컴포넌트에서 bind해서 넘긴다:
 *   const boundSendMessage = sendMessage.bind(null, conversationId)
 *   useActionState(boundSendMessage, initialState)
 */
export async function sendMessage(
  conversationId: string,
  _prev: SendMessageState,
  formData: FormData,
): Promise<SendMessageState> {
  const body = String(formData.get('body') ?? '').trim()

  if (!isValidMessageBody(body)) {
    // 빈 메시지·공백만 있는 메시지는 조용히 무시한다.
    // 화면의 required 속성이 1차 방어선이고, 여기가 최종 방어선이다.
    return { error: null }
  }

  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { error: '로그인이 필요합니다' }

  const { error } = await supabase.from('messages').insert({
    conversation_id: conversationId,
    sender_id: user.id,
    body,
  })

  if (error) {
    // 내 대화방이 아니면 RLS(msg_insert 정책)가 여기서 막는다.
    return { error: '메시지를 보낼 수 없습니다' }
  }

  revalidatePath(`/chat/${conversationId}`)
  revalidatePath('/chat')
  return { error: null }
}

/**
 * 대화방 진입 시 읽음 시각을 갱신한다.
 * mark_conversation_read RPC — 상대에게는 노출되지 않는 "내가 어디까지 읽었는지"만 저장한다.
 */
export async function markConversationRead(conversationId: string): Promise<void> {
  const supabase = await createClient()
  await supabase.rpc('mark_conversation_read', { p_conversation: conversationId })
  revalidatePath('/chat')
}

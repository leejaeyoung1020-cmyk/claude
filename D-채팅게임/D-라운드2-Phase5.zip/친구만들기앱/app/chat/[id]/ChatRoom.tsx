'use client'

import { useActionState, useEffect, useRef, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import MessageBubble from '@/components/MessageBubble'
import { sendMessage, type SendMessageState } from '@/app/actions/chat'
import type { Message } from '@/lib/types'

type Props = {
  conversationId: string
  myId: string
  initialMessages: Message[]
}

const initialState: SendMessageState = { error: null }

/**
 * 메시지 목록 렌더링 + 전송 + 실시간 수신 (Phase 5-2, 5-3).
 *
 * ⚠️ 실시간 구독(5-3)은 Phase 0에서
 *   alter publication supabase_realtime add table messages;
 * 가 실행돼 있어야 동작한다. A 확인 전까지는 "코드는 맞는데 안 뜬다"가
 * 나올 수 있다 — 그때는 코드를 고치기 전에 이것부터 의심한다
 * (docs/agent/D-작업기록.md 참고).
 */
export default function ChatRoom({ conversationId, myId, initialMessages }: Props) {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const listRef = useRef<HTMLUListElement>(null)
  const formRef = useRef<HTMLFormElement>(null)

  const boundSendMessage = sendMessage.bind(null, conversationId)
  const [state, formAction, pending] = useActionState(boundSendMessage, initialState)

  useEffect(() => {
    const supabase = createClient()

    const channel = supabase
      .channel(`room:${conversationId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversationId}`,
        },
        (payload) => {
          const incoming = payload.new as Message
          // 내가 보낸 메시지도 같은 채널로 돌아오므로, id로 중복만 걸러낸다.
          setMessages((prev) =>
            prev.some((m) => m.id === incoming.id) ? prev : [...prev, incoming],
          )
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [conversationId])

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight })
  }, [messages.length])

  useEffect(() => {
    if (!pending && !state.error) {
      formRef.current?.reset()
    }
  }, [pending, state])

  return (
    <>
      <ul
        ref={listRef}
        className="flex flex-1 flex-col gap-1 overflow-y-auto px-4 py-4"
      >
        {messages.length === 0 && (
          <li className="py-10 text-center text-sm text-slate-400">
            첫 메시지를 보내 보세요
          </li>
        )}
        {messages.map((m) => (
          <MessageBubble
            key={m.id}
            body={m.body}
            createdAt={m.created_at}
            isMine={m.sender_id === myId}
          />
        ))}
      </ul>

      {state.error && (
        <p
          role="alert"
          className="mx-4 mb-2 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"
        >
          {state.error}
        </p>
      )}

      <form
        ref={formRef}
        action={formAction}
        className="flex shrink-0 items-end gap-2 border-t border-slate-200 bg-white px-4 py-3"
      >
        <textarea
          name="body"
          required
          rows={1}
          maxLength={1000}
          placeholder="메시지 보내기"
          className="max-h-32 flex-1 resize-none rounded-2xl border border-slate-300 px-4 py-2.5 text-[15px] outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              formRef.current?.requestSubmit()
            }
          }}
        />
        <button
          type="submit"
          disabled={pending}
          className="shrink-0 rounded-full bg-brand-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-brand-500 disabled:opacity-50"
        >
          전송
        </button>
      </form>
    </>
  )
}

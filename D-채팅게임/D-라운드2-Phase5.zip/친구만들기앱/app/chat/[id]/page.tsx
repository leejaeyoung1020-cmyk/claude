import Link from 'next/link'
import { notFound, redirect } from 'next/navigation'
import { createClient, hasSupabaseEnv } from '@/lib/supabase/server'
import { getMyProfile } from '@/lib/auth'
import { markConversationRead } from '@/app/actions/chat'
import type { Message, Profile } from '@/lib/types'
import ChatRoom from './ChatRoom'

export const dynamic = 'force-dynamic'

type PartnerProfile = Pick<Profile, 'id' | 'nickname' | 'photo_url'>

type ConversationRow = {
  id: string
  user_a: string
  user_b: string
  partner_a: PartnerProfile | null
  partner_b: PartnerProfile | null
}

export default async function ChatRoomPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params

  if (!hasSupabaseEnv()) {
    return (
      <main className="mx-auto max-w-lg px-6 py-10">
        <p className="text-sm text-slate-500">Supabase 연결 전입니다.</p>
      </main>
    )
  }

  const me = await getMyProfile()
  if (!me) redirect('/login')

  const supabase = await createClient()

  // 내 대화방인지 확인. 화면에서 링크를 숨기는 것만으로는 부족하다 —
  // .or() 조건 자체가 내 id가 없으면 결과를 안 준다. RLS(conv_read 정책)가
  // 같은 조건을 한 번 더 강제하므로 이중 방어다.
  const { data: convRow } = await supabase
    .from('conversations')
    .select(
      `id, user_a, user_b,
       partner_a:profiles!conversations_user_a_fkey(id, nickname, photo_url),
       partner_b:profiles!conversations_user_b_fkey(id, nickname, photo_url)`,
    )
    .eq('id', id)
    .or(`user_a.eq.${me.id},user_b.eq.${me.id}`)
    .maybeSingle()

  const conversation = convRow as unknown as ConversationRow | null
  if (!conversation) notFound()

  const partner =
    conversation.user_a === me.id ? conversation.partner_b : conversation.partner_a

  const { data: messageRows } = await supabase
    .from('messages')
    .select('id, conversation_id, sender_id, body, created_at')
    .eq('conversation_id', id)
    .order('created_at', { ascending: true })

  await markConversationRead(id)

  return (
    <main className="mx-auto flex h-dvh max-w-lg flex-col">
      <header className="flex shrink-0 items-center gap-3 border-b border-slate-200 px-4 py-3">
        <Link
          href="/chat"
          aria-label="대화 목록으로"
          className="rounded-full p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-700"
        >
          ←
        </Link>
        <p className="flex-1 truncate font-semibold text-slate-900">
          {partner?.nickname ?? '알 수 없음'}
        </p>
        <Link
          href={`/chat/${id}/meet`}
          className="shrink-0 rounded-full border border-brand-200 bg-brand-50 px-3 py-1.5 text-sm font-medium text-brand-700 transition-colors hover:bg-brand-100"
        >
          만났어요
        </Link>
      </header>

      <ChatRoom
        conversationId={id}
        myId={me.id}
        initialMessages={(messageRows as Message[]) ?? []}
      />
    </main>
  )
}

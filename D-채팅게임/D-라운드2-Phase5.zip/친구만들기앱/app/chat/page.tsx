import Link from 'next/link'
import { redirect } from 'next/navigation'
import { createClient, hasSupabaseEnv } from '@/lib/supabase/server'
import { getMyProfile } from '@/lib/auth'
import type { Profile } from '@/lib/types'

export const dynamic = 'force-dynamic'

type PartnerProfile = Pick<Profile, 'id' | 'nickname' | 'photo_url'>

type ConversationRow = {
  id: string
  user_a: string
  user_b: string
  created_at: string
  partner_a: PartnerProfile | null
  partner_b: PartnerProfile | null
}

type MessageRow = {
  id: string
  conversation_id: string
  sender_id: string
  body: string
  created_at: string
}

/**
 * 대화방 목록 (Phase 5-1).
 *
 * partner_a/partner_b: conversations.user_a/user_b가 같은 profiles 테이블을
 * 두 번 참조하므로, Postgres 기본 제약 이름(conversations_user_a_fkey /
 * conversations_user_b_fkey)으로 각각 임베드해서 구분한다.
 */
export default async function ChatListPage() {
  if (!hasSupabaseEnv()) {
    return (
      <main className="mx-auto max-w-lg px-6 py-10">
        <p className="text-sm text-slate-500">Supabase 연결 전입니다.</p>
      </main>
    )
  }

  const me = await getMyProfile()
  if (!me) redirect('/login')

  const supabase = await createClient()

  const { data: convRows, error: convError } = await supabase
    .from('conversations')
    .select(
      `id, user_a, user_b, created_at,
       partner_a:profiles!conversations_user_a_fkey(id, nickname, photo_url),
       partner_b:profiles!conversations_user_b_fkey(id, nickname, photo_url)`,
    )
    .or(`user_a.eq.${me.id},user_b.eq.${me.id}`)
    .order('created_at', { ascending: false })

  if (convError) {
    return (
      <main className="mx-auto max-w-lg px-6 py-10">
        <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">
          대화방 목록을 불러오지 못했습니다: {convError.message}
        </p>
      </main>
    )
  }

  const conversations = (convRows as unknown as ConversationRow[]) ?? []
  const ids = conversations.map((c) => c.id)

  const [{ data: messageRows }, { data: readRows }] = ids.length
    ? await Promise.all([
        supabase
          .from('messages')
          .select('id, conversation_id, sender_id, body, created_at')
          .in('conversation_id', ids)
          .order('created_at', { ascending: false }),
        supabase
          .from('conversation_reads')
          .select('conversation_id, last_read_at')
          .eq('user_id', me.id)
          .in('conversation_id', ids),
      ])
    : [{ data: [] as MessageRow[] }, { data: [] as { conversation_id: string; last_read_at: string }[] }]

  const messages = (messageRows as MessageRow[]) ?? []
  const lastReadByConv = new Map(
    ((readRows as { conversation_id: string; last_read_at: string }[]) ?? []).map((r) => [
      r.conversation_id,
      r.last_read_at,
    ]),
  )

  const lastMessageByConv = new Map<string, MessageRow>()
  const unreadCountByConv = new Map<string, number>()

  // messages는 최신순 정렬이므로, 대화방별 첫 등장이 곧 마지막 메시지다.
  for (const m of messages) {
    if (!lastMessageByConv.has(m.conversation_id)) {
      lastMessageByConv.set(m.conversation_id, m)
    }
    const lastRead = lastReadByConv.get(m.conversation_id)
    const isUnread = m.sender_id !== me.id && (!lastRead || new Date(m.created_at) > new Date(lastRead))
    if (isUnread) {
      unreadCountByConv.set(m.conversation_id, (unreadCountByConv.get(m.conversation_id) ?? 0) + 1)
    }
  }

  return (
    <main className="mx-auto max-w-lg px-4 py-8">
      <h1 className="px-2 text-2xl font-bold text-brand-900">대화</h1>

      {conversations.length === 0 ? (
        <div className="mt-12 flex flex-col items-center gap-3 px-6 text-center">
          <p className="text-slate-600">아직 대화가 없어요. 검색에서 친구를 찾아보세요.</p>
          <Link
            href="/search"
            className="rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-brand-500"
          >
            친구 찾으러 가기
          </Link>
        </div>
      ) : (
        <ul className="mt-4 divide-y divide-slate-100">
          {conversations.map((c) => {
            const partner = c.user_a === me.id ? c.partner_b : c.partner_a
            const last = lastMessageByConv.get(c.id)
            const unread = unreadCountByConv.get(c.id) ?? 0

            return (
              <li key={c.id}>
                <Link
                  href={`/chat/${c.id}`}
                  className="flex items-center gap-3 px-2 py-3.5 transition-colors hover:bg-slate-50"
                >
                  <PlaceholderAvatar
                    photoUrl={partner?.photo_url ?? null}
                    nickname={partner?.nickname ?? '?'}
                  />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate font-medium text-slate-900">
                        {partner?.nickname ?? '알 수 없음'}
                      </p>
                      {last && (
                        <span className="shrink-0 text-xs text-slate-400">
                          {formatListTime(last.created_at)}
                        </span>
                      )}
                    </div>
                    <p className="truncate text-sm text-slate-500">
                      {last ? last.body : '대화를 시작해 보세요'}
                    </p>
                  </div>

                  {unread > 0 && (
                    <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-brand-600 px-1.5 text-[11px] font-semibold text-white">
                      {unread > 99 ? '99+' : unread}
                    </span>
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </main>
  )
}

/**
 * B의 components/Avatar.tsx가 나오기 전까지 쓰는 임시 표시.
 * 나오면 이 함수를 지우고 <Avatar ... />로 교체한다 (D-채팅게임/tasks.md 5-1 참고).
 * Avatar.tsx와 이름이 겹치지 않도록 컴포넌트 파일로 따로 만들지 않았다.
 */
function PlaceholderAvatar({ photoUrl, nickname }: { photoUrl: string | null; nickname: string }) {
  if (photoUrl) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={photoUrl} alt="" className="h-12 w-12 shrink-0 rounded-full object-cover" />
  }
  return (
    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-semibold text-brand-700">
      {nickname.slice(0, 1)}
    </div>
  )
}

function formatListTime(iso: string): string {
  const date = new Date(iso)
  const now = new Date()
  const sameDay = date.toDateString() === now.toDateString()

  if (sameDay) {
    return new Intl.DateTimeFormat('ko-KR', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Asia/Seoul',
    }).format(date)
  }
  return new Intl.DateTimeFormat('ko-KR', {
    month: 'numeric',
    day: 'numeric',
    timeZone: 'Asia/Seoul',
  }).format(date)
}

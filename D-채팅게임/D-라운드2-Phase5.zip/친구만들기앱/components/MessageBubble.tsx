/**
 * MessageBubble — 채팅 말풍선 한 개
 *
 * 담당: D (Phase 5-2)
 * 의존성 없음. props만 받는 순수 컴포넌트이므로 Phase 0 전에도 만들 수 있습니다.
 *
 * 부모는 <ul>이어야 합니다:
 *   <ul className="flex flex-col gap-1">
 *     {messages.map(m => <MessageBubble key={m.id} ... />)}
 *   </ul>
 *
 * 만들지 않는 것 (SPEC 4.4 제외 항목):
 *   - 읽음 확인 표시("상대가 읽음")
 *   - 사진·파일·이모티콘 전송
 *   - 메시지 삭제·수정
 */

export type MessageBubbleProps = {
  /** 메시지 본문. DB에서 1~1000자로 제한되어 있습니다. */
  body: string;
  /** ISO 문자열 또는 Date. Supabase는 ISO 문자열로 내려줍니다. */
  createdAt: string | Date;
  /** 내가 보낸 메시지면 true → 오른쪽 정렬 */
  isMine: boolean;
  /**
   * 시각 표시 여부. 같은 사람이 같은 분에 연달아 보낸 메시지는
   * 마지막 하나에만 true를 주면 화면이 훨씬 깔끔합니다. 기본값 true.
   */
  showTime?: boolean;
};

/**
 * 서버·클라이언트 양쪽에서 같은 결과가 나오도록 timeZone을 고정합니다.
 * 고정하지 않으면 SSR 결과와 브라우저 결과가 달라져 hydration 경고가 뜹니다.
 */
const TIME_FORMAT = new Intl.DateTimeFormat('ko-KR', {
  hour: 'numeric',
  minute: '2-digit',
  hour12: true,
  timeZone: 'Asia/Seoul',
});

export default function MessageBubble({
  body,
  createdAt,
  isMine,
  showTime = true,
}: MessageBubbleProps) {
  const date = createdAt instanceof Date ? createdAt : new Date(createdAt);
  const timeLabel = TIME_FORMAT.format(date);

  return (
    <li
      data-testid="message-bubble"
      data-mine={isMine}
      className={[
        'flex w-full items-end gap-1.5',
        isMine ? 'flex-row-reverse' : 'flex-row',
      ].join(' ')}
    >
      <p
        className={[
          'max-w-[75%] whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2',
          'text-[15px] leading-relaxed',
          isMine
            ? 'rounded-br-sm bg-neutral-900 text-white'
            : 'rounded-bl-sm bg-neutral-100 text-neutral-900',
        ].join(' ')}
      >
        {body}
      </p>

      {showTime && (
        <time
          dateTime={date.toISOString()}
          className="shrink-0 pb-0.5 text-[11px] tabular-nums text-neutral-400"
        >
          {timeLabel}
        </time>
      )}
    </li>
  );
}

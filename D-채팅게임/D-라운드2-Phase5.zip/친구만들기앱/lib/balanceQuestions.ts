/**
 * 밸런스게임 질문 30개 — 로컬 상수
 *
 * ⚠️ 임시 파일입니다. A의 Phase 0(seed.sql)이 끝나면 DB에서 읽어 오세요.
 *    supabase/seed_balance_questions.sql 과 내용이 1:1로 같습니다.
 *
 * 교체 방법 (app/chat/[id]/meet/page.tsx):
 *
 *   // Before — 로컬 상수
 *   import { BALANCE_QUESTIONS } from '@/lib/balanceQuestions';
 *
 *   // After — Supabase
 *   const { data } = await supabase
 *     .from('balance_questions')
 *     .select('id, option_a, option_b');
 *
 * BalanceQuestion 타입은 balance_questions 테이블 컬럼명과 동일하게 맞춰 뒀으므로,
 * 데이터 출처만 바꾸면 화면 코드는 한 줄도 고칠 필요가 없습니다.
 */

export type BalanceQuestion = {
  id: number;
  option_a: string;
  option_b: string;
};

export const BALANCE_QUESTIONS: readonly BalanceQuestion[] = [
  // 음식
  { id: 1, option_a: '탕수육은 부먹', option_b: '탕수육은 찍먹' },
  { id: 2, option_a: '민트초코 좋아함', option_b: '민트초코는 못 먹음' },
  { id: 3, option_a: '치킨은 후라이드', option_b: '치킨은 양념' },
  { id: 4, option_a: '라면에 계란 넣기', option_b: '라면은 그대로' },
  { id: 5, option_a: '한 끼 먹는다면 밥', option_b: '한 끼 먹는다면 면' },
  { id: 6, option_a: '매운 거 잘 먹음', option_b: '매운 거 못 먹음' },
  { id: 7, option_a: '아이스 아메리카노', option_b: '따뜻한 아메리카노' },
  { id: 8, option_a: '점심은 학식', option_b: '점심은 학교 밖에서' },

  // 학교생활
  { id: 9, option_a: '1교시부터 몰아 듣기', option_b: '오후 수업만 골라 듣기' },
  { id: 10, option_a: '시험공부는 벼락치기', option_b: '시험공부는 미리미리' },
  { id: 11, option_a: '과제는 혼자가 편함', option_b: '과제는 같이가 편함' },
  { id: 12, option_a: '조별과제는 조장', option_b: '조별과제는 팀원' },
  { id: 13, option_a: '강의는 대면', option_b: '강의는 비대면' },
  { id: 14, option_a: '공부는 카페에서', option_b: '공부는 도서관에서' },
  { id: 15, option_a: '공부할 때 음악 켜기', option_b: '공부할 때 완전 무음' },
  { id: 16, option_a: 'MT는 무조건 참석', option_b: 'MT는 패스' },
  { id: 17, option_a: '방학엔 알바', option_b: '방학엔 여행' },

  // 생활습관
  { id: 18, option_a: '아침형 인간', option_b: '저녁형 인간' },
  { id: 19, option_a: '등하교는 지하철', option_b: '등하교는 버스' },
  { id: 20, option_a: '급한 연락은 전화로', option_b: '급한 연락은 메시지로' },
  { id: 21, option_a: '알림 다 켜두기', option_b: '알림 다 꺼두기' },
  { id: 22, option_a: '방은 늘 정리되어 있어야 함', option_b: '방은 좀 어질러도 괜찮음' },
  { id: 23, option_a: '쉬는 날엔 집에 있기', option_b: '쉬는 날엔 무조건 나가기' },
  { id: 24, option_a: '식당은 늘 가던 곳', option_b: '식당은 매번 새로운 곳' },

  // 취향·여가
  { id: 25, option_a: '여행은 계획 다 짜고', option_b: '여행은 발길 닿는 대로' },
  { id: 26, option_a: '여행 간다면 바다', option_b: '여행 간다면 산' },
  { id: 27, option_a: '여름이 낫다', option_b: '겨울이 낫다' },
  { id: 28, option_a: '영화는 영화관에서', option_b: '영화는 집에서' },
  { id: 29, option_a: '노래방에선 부르는 쪽', option_b: '노래방에선 듣는 쪽' },
  { id: 30, option_a: '반려동물은 강아지', option_b: '반려동물은 고양이' },
] as const;

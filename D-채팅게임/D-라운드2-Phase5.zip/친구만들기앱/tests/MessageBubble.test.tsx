/** @vitest-environment jsdom */
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import MessageBubble from '@/components/MessageBubble';

/** 2026-08-19 14:05 KST */
const KST_AFTERNOON = '2026-08-19T05:05:00.000Z';

function renderBubble(props: Partial<React.ComponentProps<typeof MessageBubble>> = {}) {
  return render(
    <ul>
      <MessageBubble
        body="안녕하세요"
        createdAt={KST_AFTERNOON}
        isMine={false}
        {...props}
      />
    </ul>,
  );
}

describe('MessageBubble', () => {
  it('본문을 그대로 보여준다', () => {
    renderBubble({ body: '내일 학식 같이 먹을래요?' });
    expect(screen.getByText('내일 학식 같이 먹을래요?')).toBeTruthy();
  });

  it('내 메시지는 오른쪽, 상대 메시지는 왼쪽에 붙는다', () => {
    const { unmount } = renderBubble({ isMine: true });
    const mine = screen.getByTestId('message-bubble');
    expect(mine.dataset.mine).toBe('true');
    expect(mine.className).toContain('flex-row-reverse');
    unmount();

    renderBubble({ isMine: false });
    const theirs = screen.getByTestId('message-bubble');
    expect(theirs.dataset.mine).toBe('false');
    expect(theirs.className).toContain('flex-row');
    expect(theirs.className).not.toContain('flex-row-reverse');
  });

  it('시각을 한국 시간대로 표시한다', () => {
    renderBubble();
    expect(screen.getByText('오후 2:05')).toBeTruthy();
  });

  it('showTime이 false면 시각을 감춘다', () => {
    const { container } = renderBubble({ showTime: false });
    expect(container.querySelector('time')).toBeNull();
  });

  it('줄바꿈이 든 본문도 원문 그대로 담는다', () => {
    renderBubble({ body: '첫 줄\n둘째 줄' });
    expect(screen.getByTestId('message-bubble').textContent).toContain('첫 줄\n둘째 줄');
  });
});

import { describe, expect, it } from 'vitest';

import { BALANCE_QUESTIONS } from '@/lib/balanceQuestions';

describe('밸런스게임 질문 데이터', () => {
  it('30개다', () => {
    expect(BALANCE_QUESTIONS).toHaveLength(30);
  });

  it('id가 1부터 30까지 중복 없이 이어진다', () => {
    const ids = BALANCE_QUESTIONS.map((q) => q.id).sort((a, b) => a - b);
    expect(ids).toEqual(Array.from({ length: 30 }, (_, i) => i + 1));
  });

  it('두 선택지가 모두 채워져 있고 서로 다르다', () => {
    for (const q of BALANCE_QUESTIONS) {
      expect(q.option_a.trim().length).toBeGreaterThan(0);
      expect(q.option_b.trim().length).toBeGreaterThan(0);
      expect(q.option_a).not.toBe(q.option_b);
    }
  });

  it('선택지가 화면에서 잘리지 않을 길이다 (20자 이하)', () => {
    for (const q of BALANCE_QUESTIONS) {
      expect(q.option_a.length).toBeLessThanOrEqual(20);
      expect(q.option_b.length).toBeLessThanOrEqual(20);
    }
  });

  it('같은 조합이 두 번 들어 있지 않다', () => {
    const pairs = BALANCE_QUESTIONS.map((q) => `${q.option_a}|${q.option_b}`);
    expect(new Set(pairs).size).toBe(pairs.length);
  });
});

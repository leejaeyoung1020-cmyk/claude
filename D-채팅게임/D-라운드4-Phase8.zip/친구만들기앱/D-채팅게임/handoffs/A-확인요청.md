# A에게 — 확인 요청 사항 (D 트랙, 2026-08-19)

D가 Phase 5 작업 중 저장소를 검증하다 발견한 것들입니다.
전부 A 담당 영역이라 **D가 직접 고치지 않고** 전달만 합니다.

---

## 1. 🔴 `친구만들기앱/lib/auth.ts` 누락 — 최우선

`친구만들기앱/lib/` 에 `auth.ts` 가 없습니다. 그런데 아래 파일들이 이걸 import 합니다.

| 파일 | 가져다 쓰는 것 |
|---|---|
| `app/actions/auth.ts` | `demoPassword` |
| `app/suspended/page.tsx` | `getMyProfile`, `isSuspended` |
| `app/admin/page.tsx` | `getMyProfile` |
| `app/chat/page.tsx` (D 신규) | `getMyProfile` |
| `app/chat/[id]/page.tsx` (D 신규) | `getMyProfile` |

**증상:** 저장소를 그대로 clone 해서 `npm run build` 하면 아래 오류로 실패합니다.

```
error TS2307: Cannot find module '@/lib/auth' or its corresponding type declarations.
```

**원인 추정:** `0/lib/auth.ts` 에는 파일이 있습니다. push 과정에서 `친구만들기앱/lib/` 로 옮겨지지 않은 것으로 보입니다.

**조치:** `0/lib/auth.ts` 를 `친구만들기앱/lib/auth.ts` 로 옮겨 주세요.
(D 쪽 검증에서는 이 파일을 임시로 가져다 놓고 빌드를 통과시켰습니다.
 D 결과물 zip 에도 참고용으로 같은 파일을 넣어 뒀지만, **A가 원본을 확정해 주세요.**
 `lib/` 은 A 소유 영역이라 D가 임의로 정본을 정하지 않습니다.)

---

## 2. 🔴 `app/admin/ReportRow.tsx` — `npm run lint` 실패

```
app/admin/ReportRow.tsx
  20:70  error  Cannot call impure function during render
         `Date.now` is an impure function.   react-hooks/purity
```

해당 줄:

```tsx
const suspended =
  row.suspended_until && new Date(row.suspended_until).getTime() > Date.now()
```

렌더 중에 `Date.now()` 를 호출해서 걸립니다. `lib/auth.ts` 에 이미 있는
`isSuspended()` 를 쓰거나, `useState`/`useEffect` 로 마운트 후에 계산하면 해결됩니다.
**정지 여부 판정은 A 영역이라 D가 손대지 않았습니다.**

---

## 3. `alter publication supabase_realtime add table messages;` 실행 여부

`supabase/migrations/001~005` 와 `seed.sql` 을 전부 검색했지만 이 문장이 없습니다.
Supabase 대시보드(Database → Replication)에서 직접 켜셨다면 괜찮습니다.

**D Phase 5-3(실시간 수신)의 유일한 전제 조건**이라, 안 켜져 있으면
코드가 맞아도 메시지가 상대 화면에 안 뜹니다. 한 줄만 확인해 주세요.

켜져 있지 않다면 migration 파일에 남겨 두시는 걸 권합니다 (형상 관리 목적).

---

## 4. `seed_balance_questions.sql` — 마무리됨, 조치 불필요

라운드 1 때 참고용으로 넘겼던 파일입니다. 확인해 보니 `supabase/seed.sql` 에
밸런스게임 질문 30개가 이미 들어가 있어서, **`seed.sql` 을 원본으로 확정하고
D 쪽 사본은 지웠습니다.** A 가 따로 할 일은 없습니다.

참고로 D 의 `tests/balanceQuestions.test.ts` 가 이제 `supabase/seed.sql` 을
**읽기만 해서** 아래를 검사합니다 (파일은 고치지 않습니다).

- 질문이 30개인지
- id 가 겹치지 않는지
- 빈 선택지가 없는지
- 선택지가 20자를 넘지 않는지 — 폰 화면에서 32px 로 읽혀야 하는 요구에서 나온 값

질문을 고치실 때 이 테스트가 깨지면 위 네 가지 중 하나가 어긋난 것입니다.
길이 제한이 실제와 안 맞으면 알려 주세요. D 가 기준을 맞추겠습니다.

## 5. 시드 대화방으로는 채팅 화면 확인이 안 됩니다 (버그 아님, 공유용)

`seed.sql` 의 대화방은 **하은 ↔ 주원** 사이에 있는데 둘 다 더미 계정이라
`encrypted_password = 'DUMMY-NO-LOGIN'` 으로 **로그인할 수 없습니다.**
의도하신 대로 동작하는 것이지만, 그 결과 D 의 체크리스트에 있는

> 🔍 시드 데이터의 대화방 1개가 목록에 보인다

는 **로그인해서는 확인할 수 없습니다.** (로그인한 계정의 대화방이 아니므로 정상적으로 안 보입니다.)

**D 쪽 대응:** 테스트 계정 2개를 실제로 만들고 그 둘 사이에 대화방을 SQL 로 하나 넣어
확인하는 절차를 `docs/QA-D-채팅게임.md` 에 적어 뒀습니다. D 는 이대로 진행하면 되고
A 가 고치실 것은 없습니다.

**다만 B·C 도 같은 문제를 만날 수 있습니다.** 더미 계정으로 로그인해야 확인되는
항목이 각 tasks.md 에 더 있는지 한 번 훑어보시면 좋겠습니다. 필요하면
"더미 계정은 로그인 불가 — 확인은 실제 가입 계정 2개로" 를 각 tasks.md 앞부분에
한 줄 적어 두는 것을 제안합니다.

---

## D 쪽 진행 상황

- Phase 5 (대화방 목록 · 메시지 송수신 · 실시간 구독 · 읽음 처리) 코드 작성 완료
- 병합 상태에서 `npx tsc --noEmit` 0 errors, `npx next build` 성공 확인
- 남은 것은 실제 Supabase 연결 후 눈으로 확인하는 항목들입니다
- `app/chat/[id]/page.tsx` 완성 → **B에게 신고 진입점 붙여도 된다고 알려도 됩니다**

import { notFound, redirect } from 'next/navigation'
import { createClient, hasSupabaseEnv } from '@/lib/supabase/server'
import { getMyProfile } from '@/lib/auth'
import type { BalanceQuestion } from '@/lib/balanceQuestions'
import MeetGame from './MeetGame'

export const dynamic = 'force-dynamic'

/**
 * 대면 밸런스게임 진입점 (plan.md Phase 8)
 *
 * 담당: D
 *
 * 여기서 하는 일은 두 가지뿐입니다.
 *   1. 내 대화방이 맞는지 확인 — 대화방 화면과 같은 기준으로 막습니다.
 *      (링크를 숨기는 것만으로는 주소창 직접 입력을 못 막습니다)
 *   2. balance_questions 30개를 한 번에 읽어 화면에 넘깁니다.
 *      질문을 넘길 때마다 다시 조회하지 않습니다 — 대면 상황에서 끊기면 안 되므로.
 *
 * 답은 저장하지 않습니다. 이 파일에도 MeetGame 에도 insert 가 없습니다.
 */
export default async function MeetPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params

  if (!hasSupabaseEnv()) {
    return (
      <main className="mx-auto max-w-lg px-6 py-10">
        <p className="text-sm text-slate-500">Supabase 연결 전입니다.</p>
      </main>
    )
  }

  const me = await getMyProfile()
  if (!me) redirect('/login')

  const supabase = await createClient()

  // 대화방 화면(app/chat/[id]/page.tsx)과 동일한 접근 제어.
  // 참여자가 아니면 .or() 조건 자체가 결과를 안 주고, RLS conv_read 가 한 번 더 막습니다.
  const { data: conversation } = await supabase
    .from('conversations')
    .select('id')
    .eq('id', id)
    .or(`user_a.eq.${me.id},user_b.eq.${me.id}`)
    .maybeSingle()

  if (!conversation) notFound()

  const { data: questionRows, error } = await supabase
    .from('balance_questions')
    .select('id, option_a, option_b')
    .order('id', { ascending: true })

  const questions = (questionRows as BalanceQuestion[]) ?? []

  // 질문이 없으면 빈 화면 대신 이유를 알려 줍니다.
  // seed.sql 이 아직 안 들어갔을 때 여기로 옵니다.
  if (error || questions.length === 0) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-lg flex-col items-center justify-center gap-3 px-8 text-center">
        <p className="text-lg font-semibold text-slate-900">질문을 불러오지 못했어요</p>
        <p className="text-sm text-slate-500">
          잠시 후 다시 시도해 주세요. 계속 이러면 담당자에게 알려 주세요.
        </p>
        <a
          href={`/chat/${id}`}
          className="mt-2 rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700"
        >
          대화방으로 돌아가기
        </a>
      </main>
    )
  }

  return <MeetGame questions={questions} chatHref={`/chat/${id}`} />
}

# D 트랙 작업 기록

담당: D (채팅 · 밸런스게임) · 참고: [../../tasks.md](../../tasks.md) · [../../D-채팅게임/tasks.md](../../D-채팅게임/tasks.md)

---

## D 단계 지도

| 단계 | 내용 | 상태 |
|---|---|---|
| 1 | 선행 산출물(밸런스게임 화면·말풍선) 정식 경로 배치 + 검증 | ✅ 완료 (라운드 1) |
| 2 | Phase 5 코드 — 대화방 목록·메시지 전송·실시간 구독·읽음 처리 | ✅ 완료 (라운드 2) |
| 3 | Phase 8 마무리 — 질문을 DB 조회로 전환, 로컬 상수 제거 | ✅ 완료 (라운드 3) |
| **4** | **QA 대본 작성 — Supabase 연결 후 확인할 순서를 문서로** | ✅ **완료 (라운드 4, 이번)** |
| 5 | 실제 연결 검증 — 🔍 항목 전부 눈으로 확인 | 🔒 A 대기 (`lib/auth.ts`) |
| 6 | 통합 — B의 `Avatar.tsx` 교체, C의 수락 흐름으로 재검증 | 🔒 B·C 대기 |
| 7 | 병합 — `docs/QA.md` 기록 후 커밋 분리해서 `main` 병합 | 대기 |

**여기까지가 다른 사람을 안 기다리고 할 수 있는 전부입니다.** 단계 5부터는 A의 `lib/auth.ts` 와 Supabase 연결이 있어야 합니다.

## 담당자별 전달사항 (`D-채팅게임/handoffs/`)

| 파일 | 대상 | 핵심 내용 |
|---|---|---|
| `A-확인요청.md` | A | 🔴 `lib/auth.ts` 누락(빌드 실패) · 🔴 `ReportRow.tsx` lint 오류 · realtime publication 확인 · 시드 더미계정 로그인 불가 공유 |
| `B-전달사항.md` | B | 신고 진입점 부착 가능한 위치 안내 · `Avatar.tsx` 교체 지점 1곳 |
| `C-전달사항.md` | C | 수락→대화방 연결 코드 예시 (`respond_friend_request` 반환값 활용) |

## QA 대본

`docs/QA-D-채팅게임.md` — Supabase 연결 후 순서대로 따라 하면 Phase 5·8 의 🔍 35개 항목이 끝난다.

---

## 라운드 4 — 2026-08-19 (QA 대본)

### 한 일

`docs/QA-D-채팅게임.md` 를 만들었다. Supabase 가 연결되는 순간 순서대로 따라만 하면
Phase 5·8 의 🔍 항목이 전부 끝나도록, 절차·통과 기준·실패 시 볼 곳을 표로 정리했다.
Windows PowerShell 명령과 폰 접속 방법(`npm run dev -- -H 0.0.0.0`, 방화벽 안내)까지 넣었다.

**파일을 `docs/QA.md` 가 아니라 따로 만든 이유.** `docs/QA.md` 는 A·B·C·D 가 함께 쓰는
파일이라 네 명이 동시에 고치면 충돌이 난다. D 는 자기 대본과 결과를 별도 파일에 적고,
병합할 때 통과 한 줄 요약만 `docs/QA.md` 로 옮기기로 했다.

### 🔴 대본을 쓰다 발견한 것 — 시드 대화방으로는 확인이 안 된다

`seed.sql` 의 대화방은 하은 ↔ 주원 사이에 있는데, 둘 다 더미 계정이라
`encrypted_password = 'DUMMY-NO-LOGIN'` 으로 **로그인할 수 없다.** seed 주석에
명시된 의도된 동작이지만, 그 결과 D 체크리스트의

> 🔍 시드 데이터의 대화방 1개가 목록에 보인다

는 로그인해서는 확인할 수 없다. 로그인한 계정의 대화방이 아니므로 정상적으로 안 보인다.

**대응:** 테스트 계정 2개를 실제로 만들고 그 둘 사이에 대화방을 SQL 로 넣는 절차를
대본 1절에 넣었다. `conversations` 에 `check (user_a < user_b)` 가 걸려 있어
`least`/`greatest` 를 쓰지 않으면 실패하므로, 그대로 붙여넣어 돌아가는 형태로 적어 뒀다.
C 의 Phase 4(신청 수락)가 끝나면 이 SQL 대신 실제 수락 흐름으로 다시 확인한다.

같은 문제를 B·C 도 만날 수 있어 `handoffs/A-확인요청.md` 5번으로 공유했다.

### 대본에 넣은 확인 항목 수

| 구간 | 항목 |
|---|---|
| 0. 시작 전 확인 | 4 |
| 5-1 대화방 목록 | 4 |
| 5-2 메시지 주고받기 | 9 |
| 5-3 실시간 | 4 |
| 5-4 안 읽은 표시 | 4 |
| 8 밸런스게임 | 10 |
| **합계** | **35** |

접근 제어(5-2-i, 8-j)와 "답을 저장하지 않는다"(8-h, 8-i)처럼 **어기면 안 되는 항목**은
실패 시 즉시 알리라고 따로 적어 뒀다.

---

## 라운드 3 — 2026-08-19 (Phase 8 마무리 · 질문을 DB 조회로 전환)

### 한 일

밸런스게임 질문을 `lib/balanceQuestions.ts` 의 로컬 상수 대신 `balance_questions` 테이블에서 읽도록 바꿨다. 라운드 1부터 달아 두었던 `TODO(Phase 8)` 을 해소한 것이다.

| 파일 | 변경 |
|---|---|
| `app/chat/[id]/meet/page.tsx` | 클라이언트 → **서버 컴포넌트**. 참여자 확인 + 질문 30개 조회 후 props 로 전달 |
| `app/chat/[id]/meet/MeetGame.tsx` | **신규.** 기존 화면 코드를 그대로 옮김. 질문을 props 로 받는다 |
| `lib/balanceQuestions.ts` | 30개 상수 **제거**. 타입 + `shuffle()` 순수 함수만 남김 |
| `tests/balanceQuestions.test.ts` | 상수 검사 → **`supabase/seed.sql` 직접 검사** + `shuffle()` 검사 |

### 왜 이렇게 나눴나

**상수를 지운 이유.** seed 가 반영된 뒤로 질문 원본이 두 벌(`lib` 상수, `seed.sql`)이 되어 서로 어긋날 위험만 남았다. 실제로 두 목록의 내용이 이미 달랐다 (`lib` 의 id 1 은 "탕수육은 부먹", seed 의 id 1 은 "평생 여름만"). 원본을 `seed.sql` 하나로 정리했다.

**테스트가 지키던 보증을 잃지 않게 옮겼다.** 예전 테스트는 상수를 상대로 "30개 · id 중복 없음 · 길이 제한" 을 확인했다. 상수를 지우면 이 보증이 사라지므로, `supabase/seed.sql` 을 직접 읽어 같은 항목을 검사하도록 다시 썼다. 길이 제한(20자)은 폰 화면에서 32px 로 읽혀야 한다는 요구에서 나온 값이라, A 가 질문을 고쳤을 때 화면이 깨지는 걸 여기서 잡는다. **`supabase/**` 는 A 담당이므로 읽기만 한다.**

**화면을 서버/클라이언트로 쪼갠 이유.** 조회는 서버에서 한 번만 하고, 섞기는 클라이언트 마운트 후에 한다. 렌더 중에 섞으면 서버와 클라이언트 결과가 달라 hydration 오류가 난다. 대화방 화면을 `page.tsx` + `ChatRoom.tsx` 로 나눈 것과 같은 구조라 읽기도 일관된다.

**접근 제어를 여기에도 넣었다.** 예전 화면은 클라이언트라 주소창에 `/chat/아무id/meet` 를 직접 쳐도 열렸다. 서버 컴포넌트가 되면서 대화방 화면과 같은 기준(`.or(user_a.eq.me, user_b.eq.me)` + RLS)으로 막았다.

**질문이 0개일 때 화면을 따로 뒀다.** seed 가 아직 안 들어간 상태에서 들어오면 빈 화면 대신 이유와 돌아가기 버튼을 보여준다.

### 검증

| 검증 | 결과 |
|---|---|
| `npx tsc --noEmit` | ✅ 0 errors |
| `npx next build` | ✅ 성공, `/chat/[id]/meet` 라우트 정상 |
| `npx vitest run` | ✅ 37개 중 36개 통과 (**34 → 37 로 증가**) |
| `npx eslint` (D 영역) | ✅ 0 errors |

실패 1건은 라운드 1부터 보고한 sandbox Node 의 small-icu 이슈로 코드 결함이 아니다.

### 남은 것

Phase 8 에서 코드로 할 수 있는 일은 끝났다. 남은 항목은 전부 🔍 (실기기 확인)이고, Supabase 연결이 있어야 한다 — 질문을 DB 에서 읽게 되었으므로 이제 이 화면도 연결 없이는 확인할 수 없다.

---

## 라운드 2 — 2026-08-19 (Phase 5 · 1:1 채팅)

### 결론 먼저

Phase 5 코드를 전부 작성했고, **`0` 폴더 파일까지 합친 전체 트리에서 `npx next build` 가 성공**하는 것을 확인했다. 남은 것은 실제 Supabase 에 붙여서 눈으로 확인하는 🔍 항목들뿐이다.

```
Route (app)
├ ƒ /chat            ← D
├ ƒ /chat/[id]       ← D
├ ƒ /chat/[id]/meet  ← D
```

### 검증 방법

저장소의 `친구만들기앱/` 전체 + `0/` 에만 있던 4개 파일 + D 산출물을 한 트리로 합쳐, 실제 `package.json` 의존성을 그대로 설치하고 검증했다.

| 검증 | 결과 |
|---|---|
| `npx tsc --noEmit` | ✅ 0 errors |
| `npx next build` | ✅ 성공 (Next.js 16.3.1 Turbopack, 컴파일 23.1s) |
| `npx vitest run` | ✅ 34개 중 33개 통과 |
| `npx eslint .` | ⚠️ 1건 — **A 영역 파일**(`app/admin/ReportRow.tsx`), D는 손대지 않고 전달 |

vitest 실패 1건은 검증 sandbox 의 Node 가 small-icu 빌드라 `Intl.DateTimeFormat('ko-KR')` 이 "PM 2:05" 를 내는 것으로, 코드 결함이 아니다. Windows 공식 Node 는 full-icu 기본 포함이라 "오후 2:05" 로 나온다. 팀 로컬에서 한 번만 확인하면 된다.

### `0` 폴더 정리

`0/` 과 `친구만들기앱/` 을 전수 비교한 결과, 겹치는 파일은 **전부 내용이 동일**하고 `0/` 에만 있는 파일이 4개였다.

| 파일 | 성격 | 조치 |
|---|---|---|
| `lib/auth.ts` | **누락된 필수 파일** | D 결과물에 참고용으로 포함. A가 정본 확정 필요 |
| `app/actions/admin.ts` | A Phase 7 | D 결과물에 넣지 않음 (A 영역) |
| `app/admin/page.tsx` | A Phase 7 | 〃 |
| `app/admin/ReportRow.tsx` | A Phase 7 | 〃 (lint 오류 있음 — A에게 전달) |

### 한 일 — Phase 5 코드

| 파일 | 내용 | 대응 항목 |
|---|---|---|
| `app/actions/chat.ts` | `sendMessage()`, `markConversationRead()` | 5-2, 5-4 |
| `app/chat/page.tsx` | 대화방 목록 — 상대 프로필 조인, 마지막 메시지, 안 읽은 배지 | 5-1 |
| `app/chat/[id]/page.tsx` | 대화방 서버 컴포넌트 — 접근 제어, 메시지 조회, "만났어요" 버튼 | 5-2, 8 |
| `app/chat/[id]/ChatRoom.tsx` | 클라이언트 — 렌더링·전송·실시간 구독·중복 제거 | 5-2, 5-3 |

기존 코드베이스 패턴(`app/actions/profile.ts` 의 `useActionState` 구조, `lib/auth.ts` 의 `getMyProfile()`, `lib/supabase/server.ts`/`client.ts`)을 그대로 따랐다.

### 설계 판단 세 가지

**접근 제어를 두 겹으로 뒀다.** 쿼리에 `.or(user_a.eq.내id, user_b.eq.내id)` 를 걸어 참여자가 아니면 결과 자체가 안 나오게 하고, 그 위에 `conversations` 의 RLS `conv_read` 정책이 DB 레벨에서 같은 조건을 강제한다. 결과가 없으면 `notFound()`. 화면에서 링크를 숨기는 것만으로는 부족하다는 tasks.md 요구를 이렇게 만족시켰다.

**전송 규칙을 화면에 두지 않았다.** 메시지 전송은 하루 신청 상한 같은 업무 규칙이 아니라서 RPC 가 없다. 대신 RLS `msg_insert` 정책이 "내 대화방에만 보낼 수 있다" 를 강제하므로, `sendMessage()` 는 형식(빈 문자열·1000자)만 보고 접근 통제는 DB 에 맡긴다.

**`PlaceholderAvatar` 를 컴포넌트 파일로 만들지 않았다.** B의 `components/Avatar.tsx` 가 아직 없어 임시 표시가 필요한데, 파일로 만들면 팀 규칙("남이 만드는 컴포넌트를 직접 새로 만들지 않는다")과 부딪히고 이름도 겹친다. `app/chat/page.tsx` 안의 지역 함수로만 뒀으므로, B의 Avatar 가 나오면 호출부만 `<Avatar />` 로 바꾸고 함수를 지우면 된다.

### 고친 것

`app/chat/[id]/meet/page.tsx`(라운드 1 산출물)의 마운트 시 셔플 로직이 `react-hooks/set-state-in-effect` 규칙에 걸려 `npm run lint` 가 실패하는 상태였다. hydration 오류를 피하려고 의도적으로 마운트 후에만 섞는 패턴이라 규칙 쪽 오탐으로 판단, 사유를 주석에 남기고 `eslint-disable-next-line` 으로 처리했다.

### 아직 못 한 것 (🔍 — 실제 Supabase 연결 + 브라우저 필요)

- 시드 대화방 1개가 목록에 보이는지
- 메시지 전송 후 새로고침해도 남아 있는지, 빈 메시지가 막히는지
- 내 대화방이 아닌 id 를 주소창에 직접 입력했을 때 막히는지
- **두 창 실시간 수신** — A의 realtime publication 확인 대기
- Phase 8 실기기 확인 (글씨 크기, 30회 중복 없음, 데이터 안 쌓임)

### A에게 전달 (`D-채팅게임/handoff-to-A/A에게-확인요청.md`)

1. 🔴 `lib/auth.ts` 누락 — 이게 없으면 전체 빌드 실패
2. 🔴 `app/admin/ReportRow.tsx` lint 오류 — `Date.now()` 를 렌더 중 호출
3. `alter publication supabase_realtime add table messages;` 실행 여부
4. `seed_balance_questions.sql` — 확인 결과 `seed.sql` 에 이미 반영돼 있어 **추가 조치 불필요**

### B에게 알림

`app/chat/[id]/page.tsx` 코드 완성. **신고 진입점을 붙여도 된다.**

### 다음 라운드

1. A가 `lib/auth.ts` 반영하면 `npm run dev` 로 붙여 🔍 항목 전부 확인
2. realtime 확인되면 Phase 5 를 `docs/QA.md` 에 기록하고 `main` 병합
3. Phase 8 남은 실기기 확인 진행

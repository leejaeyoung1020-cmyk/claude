/**
 * 밸런스게임 공용 타입과 순서 섞기 (SPEC 4.6 / plan.md Phase 8)
 *
 * 담당: D
 *
 * 질문 30개의 원본은 `supabase/seed.sql` 의 `balance_questions` 테이블 하나뿐입니다.
 * 예전에는 A의 Phase 0 이 끝나기 전까지 쓰려고 이 파일에 같은 목록을 상수로
 * 들고 있었지만, seed 가 반영된 뒤로는 원본이 두 벌이 되어 서로 어긋날 위험만
 * 남으므로 상수를 지웠습니다. 질문을 고치려면 `supabase/seed.sql` 을 고칩니다
 * (해당 파일은 A 담당이므로 D 가 직접 고치지 않습니다).
 */

/** `balance_questions` 테이블 컬럼과 이름을 맞춰 둡니다. */
export type BalanceQuestion = {
  id: number;
  option_a: string;
  option_b: string;
};

/**
 * Fisher–Yates. 한 세션 안에서 같은 질문이 두 번 나오지 않도록 순서만 섞습니다.
 * 원본 배열은 건드리지 않고 새 배열을 돌려줍니다.
 *
 * 화면(MeetGame)에서 쓰지만 순수 함수라 여기 둡니다 — 그래야 테스트가 됩니다.
 */
export function shuffle(items: readonly BalanceQuestion[]): BalanceQuestion[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

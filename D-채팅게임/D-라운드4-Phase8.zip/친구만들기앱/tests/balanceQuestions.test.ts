import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'

import { shuffle, type BalanceQuestion } from '@/lib/balanceQuestions'

/**
 * 밸런스게임 (D 담당)
 *
 * 질문 30개의 원본은 supabase/seed.sql 하나뿐입니다. 예전에는 lib 에 있던 상수를
 * 검사했지만, 원본이 seed 로 옮겨졌으므로 seed 를 직접 읽어 검사합니다.
 * 그래야 A 가 질문을 고쳤을 때도 화면이 깨지지 않는 걸 보장할 수 있습니다.
 *
 * ⚠️ supabase/** 는 A 담당 영역이라 D 는 읽기만 합니다.
 */

/** seed.sql 의 balance_questions insert 문을 읽어 파싱합니다. */
function readSeedQuestions(): BalanceQuestion[] {
  const seedPath = join(process.cwd(), 'supabase', 'seed.sql')
  const sql = readFileSync(seedPath, 'utf-8')

  const start = sql.indexOf('insert into balance_questions')
  expect(
    start,
    'supabase/seed.sql 에서 balance_questions insert 문을 찾지 못했습니다',
  ).toBeGreaterThan(-1)

  const block = sql.slice(start, sql.indexOf(';', start))
  const rowPattern = /\(\s*(\d+)\s*,\s*'([^']*)'\s*,\s*'([^']*)'\s*\)/g

  const rows: BalanceQuestion[] = []
  for (const match of block.matchAll(rowPattern)) {
    rows.push({ id: Number(match[1]), option_a: match[2], option_b: match[3] })
  }
  return rows
}

describe('밸런스게임 질문 원본 (supabase/seed.sql)', () => {
  const questions = readSeedQuestions()

  it('질문이 30개 들어 있다', () => {
    expect(questions).toHaveLength(30)
  })

  it('id가 겹치지 않는다', () => {
    const ids = questions.map((q) => q.id)
    expect(new Set(ids).size).toBe(ids.length)
  })

  it('빈 선택지가 없다', () => {
    for (const q of questions) {
      expect(q.option_a.trim().length, `id ${q.id}의 option_a가 비어 있다`).toBeGreaterThan(0)
      expect(q.option_b.trim().length, `id ${q.id}의 option_b가 비어 있다`).toBeGreaterThan(0)
    }
  })

  it('선택지가 너무 길지 않다 (폰 화면에서 32px로 읽혀야 하므로 20자 이내)', () => {
    for (const q of questions) {
      expect(q.option_a.length, `id ${q.id}의 option_a가 너무 길다: "${q.option_a}"`).toBeLessThanOrEqual(20)
      expect(q.option_b.length, `id ${q.id}의 option_b가 너무 길다: "${q.option_b}"`).toBeLessThanOrEqual(20)
    }
  })
})

describe('shuffle()', () => {
  const sample: BalanceQuestion[] = Array.from({ length: 30 }, (_, i) => ({
    id: i + 1,
    option_a: `a${i + 1}`,
    option_b: `b${i + 1}`,
  }))

  it('개수가 그대로다', () => {
    expect(shuffle(sample)).toHaveLength(sample.length)
  })

  it('질문이 하나도 빠지거나 중복되지 않는다', () => {
    const ids = shuffle(sample).map((q) => q.id).sort((x, y) => x - y)
    expect(ids).toEqual(sample.map((q) => q.id))
  })

  it('원본 배열을 건드리지 않는다', () => {
    const before = [...sample]
    shuffle(sample)
    expect(sample).toEqual(before)
  })

  it('빈 배열도 안전하다', () => {
    expect(shuffle([])).toEqual([])
  })
})

# D 트랙 선행작업 — Phase 0 이전 산출물

Phase 0(A 담당)을 기다리지 않고 만들 수 있는 D 트랙 결과물입니다.
DB·Supabase 연결에 의존하는 코드가 한 줄도 없습니다.

## 들어 있는 것

| 파일 | 대응 항목 | 받는 사람 |
|---|---|---|
| `supabase/seed_balance_questions.sql` | A tasks 0-4 "밸런스게임 질문 30개 삽입" | **A** |
| `lib/balanceQuestions.ts` | Phase 0 전 개발용 임시 상수 | D |
| `components/MessageBubble.tsx` | D tasks 5-2 | D → B(Phase 6에서 참고) |
| `app/chat/[id]/meet/page.tsx` | D tasks Phase 8 | D |
| `tests/MessageBubble.test.tsx` | | D |
| `tests/balanceQuestions.test.ts` | | D |

## 저장소에 넣는 법 (Windows / PowerShell)

Phase 0에서 `npx create-next-app`이 끝난 **뒤에** 복사하세요.
그 전에 넣으면 create-next-app이 폴더가 비어 있지 않다며 멈춥니다.

```powershell
# 압축을 푼 위치 → $SRC, 프로젝트 루트 → $DST 로 바꿔서 실행
$SRC = "$HOME\Downloads\d-track-prework"
$DST = "$HOME\Documents\claude\친구만들기앱"

Copy-Item "$SRC\lib\*"        "$DST\lib\"        -Recurse -Force
Copy-Item "$SRC\components\*" "$DST\components\" -Recurse -Force
Copy-Item "$SRC\app\*"        "$DST\app\"        -Recurse -Force
Copy-Item "$SRC\tests\*"      "$DST\tests\"      -Recurse -Force

cd $DST
npx vitest run
npx tsc --noEmit
```

`seed_balance_questions.sql`은 복사하지 말고 **A에게 파일째 전달**하세요.
A가 `supabase/seed.sql` 안에 붙여넣습니다.

## 테스트가 안 돌면

`vitest.config.ts`는 A의 Phase 0-1 산출물입니다. 아직 없다면 아래로 만드세요.

```ts
// vitest.config.ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'node:path';

export default defineConfig({
  plugins: [react()],
  test: { environment: 'jsdom', globals: true },
  resolve: { alias: { '@': path.resolve(__dirname, '.') } },
});
```

`@/` 경로가 안 잡히면 `tsconfig.json`의 `paths`에 `"@/*": ["./*"]`가 있는지 확인하세요.
(Phase 0-1의 `--import-alias "@/*"` 옵션이 이걸 넣어 줍니다.)

## 밸런스게임 화면을 지금 바로 보려면

`app/chat/[id]/meet/page.tsx`는 DB를 안 쓰므로 로그인 없이도 열립니다.

```powershell
npm run dev
# 브라우저에서 http://localhost:3000/chat/test/meet
```

확인할 것 (D tasks Phase 8 🔍 항목):

- [ ] 폰을 책상에 놓고 팔 하나 거리에서 글씨가 읽힌다 — **실제로 해봅니다**
- [ ] "다음 질문"을 30번 눌러도 같은 질문이 두 번 안 나온다
- [ ] 답을 입력하거나 고르는 UI가 화면 어디에도 없다
- [ ] 개발자도구 Network 탭에 Supabase 요청이 하나도 안 뜬다

> 개발자도구 모바일 뷰: `F12` → `Ctrl + Shift + M` → iPhone SE(375×667)로 확인하세요.

## Phase 0이 끝난 뒤 할 일

1. `lib/balanceQuestions.ts` → DB 조회로 교체 (파일 상단 주석에 방법 있음)
2. 교체 후 `tests/balanceQuestions.test.ts`는 `seed.sql` 검증용으로 남겨 둡니다
3. `MessageBubble`을 `app/chat/[id]/page.tsx`에 붙여 Phase 5-2 시작

## 디자인 메모 (색 팔레트 확정 시)

`meet` 화면은 팔레트가 미확정이라 무채색 대비만 씁니다.
위/아래 명암 반전으로 두 선택지를 대등하게 두는 구조가 핵심이고,
팔레트가 정해지면 `bg-neutral-950` 한 곳만 브랜드 색으로 바꾸면 됩니다.
글자 크기 하한 `clamp(2rem, ...)`의 `2rem`(=32px)은 SPEC 4.6 요구치이므로 낮추지 마세요.

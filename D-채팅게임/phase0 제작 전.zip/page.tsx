'use client';

/**
 * 대면 밸런스게임 (SPEC 4.6 / plan.md Phase 8)
 *
 * 담당: D
 *
 * ⛔ 절대 추가하지 말 것
 *   - 선택지를 누르는 버튼 (선택지는 <p>입니다. 클릭 핸들러를 붙이지 마세요)
 *   - 답 입력창
 *   - 답을 보내는 서버 액션·RPC·insert
 *   답은 말로 하는 것이고, 앱은 질문만 던지고 빠집니다.
 *   화면을 나갔다 들어와도 Supabase 어느 테이블에도 데이터가 쌓이면 안 됩니다.
 *
 * 화면 전제: 폰을 책상 위에 세로로 놓고 두 사람이 함께 봅니다.
 *   - 선택지 최소 32px (아래 clamp의 하한이 2rem = 32px입니다. 낮추지 마세요)
 *   - 위/아래 명암 반전으로 두 선택지를 대등하게 나눕니다
 *     (색 팔레트가 아직 확정되지 않아 무채색 대비만 사용 — 확정되면 accent만 교체)
 *
 * TODO(Phase 8): A의 seed.sql 반영 후 BALANCE_QUESTIONS를 DB 조회로 교체
 *   const { data } = await supabase.from('balance_questions').select('id, option_a, option_b');
 *   → lib/balanceQuestions.ts 주석 참고. 타입이 같아 화면 코드는 그대로 둡니다.
 */

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';

import { BALANCE_QUESTIONS, type BalanceQuestion } from '@/lib/balanceQuestions';

/** Fisher–Yates. 한 세션 안에서 같은 질문이 두 번 나오지 않게 순서만 섞습니다. */
function shuffle(items: readonly BalanceQuestion[]): BalanceQuestion[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export default function MeetPage() {
  const params = useParams<{ id: string }>();
  const chatHref = `/chat/${params.id}`;

  const [deck, setDeck] = useState<BalanceQuestion[] | null>(null);
  const [index, setIndex] = useState(0);

  const restart = useCallback(() => {
    setDeck(shuffle(BALANCE_QUESTIONS));
    setIndex(0);
  }, []);

  // 섞기는 마운트 이후에만 합니다. 렌더 중에 섞으면 서버와 클라이언트 결과가
  // 달라져 hydration 오류가 납니다.
  useEffect(() => {
    restart();
  }, [restart]);

  const total = BALANCE_QUESTIONS.length;
  const question = deck?.[index] ?? null;
  const isFinished = deck !== null && index >= total;

  return (
    <main className="fixed inset-0 z-50 flex flex-col bg-neutral-950">
      <style>{`
        @keyframes dqInFromLeft  { from { opacity: 0; transform: translateX(-1.25rem); } to { opacity: 1; transform: none; } }
        @keyframes dqInFromRight { from { opacity: 0; transform: translateX( 1.25rem); } to { opacity: 1; transform: none; } }
        .dq-a { animation: dqInFromLeft  260ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
        .dq-b { animation: dqInFromRight 260ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
        @media (prefers-reduced-motion: reduce) {
          .dq-a, .dq-b { animation: none; }
        }
      `}</style>

      {/* 상단 바 — 진행 상황과 나가기만 둡니다 */}
      <header className="flex shrink-0 items-center justify-between px-5 py-4">
        <span className="text-sm tabular-nums text-neutral-500">
          {isFinished ? `${total} / ${total}` : `${Math.min(index + 1, total)} / ${total}`}
        </span>
        <Link
          href={chatHref}
          className="rounded-full px-3 py-1.5 text-sm text-neutral-400 transition-colors hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
        >
          나가기
        </Link>
      </header>

      {/* 질문 영역 */}
      {isFinished ? (
        <section className="flex flex-1 flex-col items-center justify-center gap-3 px-8 text-center">
          <p className="text-[clamp(1.75rem,7vw,2.5rem)] font-bold tracking-tight text-white">
            질문을 다 봤어요
          </p>
          <p className="text-base text-neutral-400">
            30개를 모두 넘겼습니다. 다시 섞어서 처음부터 볼 수 있어요.
          </p>
        </section>
      ) : (
        <section
          aria-live="polite"
          aria-atomic="true"
          className="relative flex flex-1 flex-col overflow-hidden"
        >
          {/* 위 선택지 — 잉크 바탕 */}
          <div className="flex flex-1 items-center justify-center bg-neutral-950 px-7 pb-10">
            <p
              key={`a-${index}`}
              className="dq-a text-balance text-center text-[clamp(2rem,8.5vw,3.25rem)] font-extrabold leading-[1.15] tracking-tight text-white"
            >
              {question?.option_a ?? ''}
            </p>
          </div>

          {/* 아래 선택지 — 종이 바탕. 명암을 뒤집어 두 선택지를 대등하게 둡니다 */}
          <div className="flex flex-1 items-center justify-center bg-white px-7 pt-10">
            <p
              key={`b-${index}`}
              className="dq-b text-balance text-center text-[clamp(2rem,8.5vw,3.25rem)] font-extrabold leading-[1.15] tracking-tight text-neutral-950"
            >
              {question?.option_b ?? ''}
            </p>
          </div>

          {/* 경계선 위에 앉는 vs */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute left-1/2 top-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-2 border-neutral-950 bg-white text-xl font-bold lowercase tracking-widest text-neutral-950"
          >
            vs
          </span>
        </section>
      )}

      {/* 하단 버튼 — 화면에 존재하는 유일한 조작입니다 */}
      <footer className="shrink-0 bg-white px-5 pb-8 pt-4">
        {isFinished ? (
          <div className="flex flex-col gap-2.5">
            <button
              type="button"
              onClick={restart}
              className="h-16 w-full rounded-2xl bg-neutral-950 text-xl font-bold text-white transition-transform active:scale-[0.98] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutral-950"
            >
              처음부터 다시
            </button>
            <Link
              href={chatHref}
              className="flex h-14 w-full items-center justify-center rounded-2xl border border-neutral-300 text-lg font-semibold text-neutral-700 transition-colors hover:bg-neutral-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutral-950"
            >
              대화방으로 돌아가기
            </Link>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setIndex((prev) => prev + 1)}
            disabled={deck === null}
            className="h-16 w-full rounded-2xl bg-neutral-950 text-xl font-bold text-white transition-transform active:scale-[0.98] disabled:opacity-40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutral-950"
          >
            다음 질문
          </button>
        )}
      </footer>
    </main>
  );
}
